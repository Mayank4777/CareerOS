from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from django.db import IntegrityError, transaction
from rest_framework.exceptions import APIException, NotFound

from .models import CareerProfile
from .selectors import get_profile_by_user


class CareerProfileAlreadyExistsError(APIException):
    status_code = 409
    default_detail = "Career profile already exists."
    default_code = "career_profile_exists"


@dataclass(slots=True)
class CareerProfileService:
    def create_profile(self, *, user, data: dict[str, Any]) -> CareerProfile:
        if get_profile_by_user(user) is not None:
            raise CareerProfileAlreadyExistsError

        try:
            with transaction.atomic():
                return CareerProfile.objects.create(user=user, **data)
        except IntegrityError as exc:
            raise CareerProfileAlreadyExistsError from exc

    def retrieve_profile(self, *, user) -> CareerProfile:
        profile = get_profile_by_user(user)
        if profile is None:
            raise NotFound("Career profile not found.")
        return profile

    def update_profile(self, *, user, data: dict[str, Any]) -> CareerProfile:
        profile = get_profile_by_user(user)
        if profile is None:
            raise NotFound("Career profile not found.")

        for field, value in data.items():
            setattr(profile, field, value)

        with transaction.atomic():
            profile.save()

        return profile

    def delete_profile(self, *, user) -> None:
        profile = get_profile_by_user(user)
        if profile is None:
            raise NotFound("Career profile not found.")

        with transaction.atomic():
            profile.delete()
